import { ArrowLeft, Mail, Phone, MapPin, Calendar, Edit } from 'lucide-react';
import { Link } from 'react-router-dom';

export function ProfilePage() {
  return (
    <div className="min-h-screen bg-[#FAFAFA] p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Back Button */}
        <Link 
          to="/dashboard"
          className="inline-flex items-center gap-2 text-[#6E7191] hover:text-[#4ECDC4] transition-colors mb-6"
        >
          <ArrowLeft size={20} />
          <span className="text-sm font-medium">Back to Dashboard</span>
        </Link>

        {/* Profile Header */}
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E0E0E2] mb-6">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#4ECDC4] to-[#44A08D] flex items-center justify-center text-white text-4xl font-semibold">
                M
              </div>
              <button className="absolute bottom-0 right-0 p-2 bg-white rounded-full shadow-lg border border-[#E0E0E2] hover:border-[#4ECDC4] transition-colors">
                <Edit size={16} className="text-[#6E7191]" />
              </button>
            </div>

            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-2xl font-semibold text-[#1A1D1F] mb-1">Maietry Williams</h1>
                  <p className="text-[#6E7191]">Student</p>
                </div>
                <button className="px-6 py-2.5 bg-gradient-to-r from-[#4ECDC4] to-[#44A08D] text-white rounded-xl hover:shadow-lg transition-all">
                  Edit Profile
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3 text-[#6E7191]">
                  <Mail size={18} />
                  <span className="text-sm">maietry.williams@email.com</span>
                </div>
                <div className="flex items-center gap-3 text-[#6E7191]">
                  <Phone size={18} />
                  <span className="text-sm">+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-3 text-[#6E7191]">
                  <MapPin size={18} />
                  <span className="text-sm">New York, USA</span>
                </div>
                <div className="flex items-center gap-3 text-[#6E7191]">
                  <Calendar size={18} />
                  <span className="text-sm">Joined March 2024</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E0E0E2]">
            <p className="text-[#6E7191] text-sm mb-2">Courses Enrolled</p>
            <p className="text-3xl font-semibold text-[#1A1D1F]">12</p>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E0E0E2]">
            <p className="text-[#6E7191] text-sm mb-2">Courses Completed</p>
            <p className="text-3xl font-semibold text-[#1A1D1F]">8</p>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#E0E0E2]">
            <p className="text-[#6E7191] text-sm mb-2">Certificates Earned</p>
            <p className="text-3xl font-semibold text-[#1A1D1F]">5</p>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E0E0E2] mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-[#1A1D1F]">About</h2>
            <button className="p-2 hover:bg-[#F7F7F8] rounded-lg transition-colors">
              <Edit size={18} className="text-[#6E7191]" />
            </button>
          </div>
          <p className="text-[#6E7191] leading-relaxed">
            Passionate learner focused on web development and design. Currently exploring advanced topics in React, TypeScript, 
            and modern UI/UX design principles. Always eager to learn new technologies and improve my skills.
          </p>
        </div>

        {/* Skills Section */}
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E0E0E2]">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-[#1A1D1F]">Skills</h2>
            <button className="p-2 hover:bg-[#F7F7F8] rounded-lg transition-colors">
              <Edit size={18} className="text-[#6E7191]" />
            </button>
          </div>
          <div className="flex flex-wrap gap-3">
            {['HTML', 'CSS', 'JavaScript', 'React', 'TypeScript', 'Figma', 'UI/UX Design', 'Tailwind CSS'].map((skill) => (
              <span 
                key={skill}
                className="px-4 py-2 bg-[#F7F7F8] text-[#1A1D1F] rounded-lg text-sm font-medium hover:bg-[#4ECDC4] hover:text-white transition-colors cursor-pointer"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
